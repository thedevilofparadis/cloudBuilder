using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class miglioraToretta : MonoBehaviour
{
    // Start is called before the first frame update
    public costruisci codiceCostruisci;

    void OnMouseDown()
    {
        codiceCostruisci.migliorareTorretta();
    } 
}
