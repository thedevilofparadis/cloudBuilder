using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class vendiTorretta : MonoBehaviour
{
    // Start is called before the first frame update
    public costruisci codiceCostruisci;

    void OnMouseDown()
    {
        codiceCostruisci.vendereTorretta();
    }
}
